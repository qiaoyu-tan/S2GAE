try:
    from .mol import smiles2graph
except ImportError:
    pass