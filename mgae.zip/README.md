# MGAE

This is a pytorch and pytorch-geometric based implementation of **Mased Graph Autoencoder: 70% Edges Could Be Reduandant for Graph Learning**. 

## Installation

The required packages can be installed by running `pip install -r requirements.txt`.

## Masked Graph Autoencoders

## Datasets
The datasets used in our paper can be automatically downlowad. 

## Quick Start
Train on the Planetoid datasets (Cora, CiteSeer, and Pubmed):
```
python mgae_main_planetoid.py --dataset "Cora" 
```